//
//  ContentView.swift
//  NeedaApp
//
//  Created by shouq on 17/08/1445 AH.
//

import SwiftUI

struct ContentView: View {
    @State private var showingPatientRegistration = false
    @State private var showingPractitionerRegistration = false
    @Environment(\.presentationMode) var presentationMode
    var body: some View {
        NavigationStack{
 
            ZStack {
                Image("background")
                    .resizable()
                    .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                    .edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
                
                
                Image("needa")
                    .resizable()
                    .frame(width:330, height:400) //width:430, height:500 -> width:330, height:400 
                    .offset(x:0, y:-100)
                
                
                
                Button(action: {
                                   self.showingPatientRegistration = true
                               }) {
                                   Text("تسجيل الدخول كمستخدم")
                                       .frame( maxWidth: 350, minHeight: 50)
                                       .background(Color("button"))
                                       .foregroundColor(.white)
                                       .cornerRadius(30)
                                       .padding(.horizontal)
                               }.padding(.top, 290) //190 -> 290
                               .fullScreenCover(isPresented: $showingPatientRegistration) {
                                   patientRegestrationPage()
                               }

                               Button(action: {
                                   self.showingPractitionerRegistration = true
                               }) {
                                   Text("تسجيل الدخول كممارس صحي")
                                       .frame( maxWidth: 350, minHeight: 50)                    .background(Color("button"))
                                       .foregroundColor(.white)
                                       .cornerRadius(30)
                                       .padding(.horizontal)
                               }.padding(.top, 420) //370 -> 420
                               .fullScreenCover(isPresented: $showingPractitionerRegistration) {
                                   PractitionerRegestrationPage()
                               }

         
                HStack{
                    Text("دخول")
                        .foregroundColor(Color("button"))
                    
                    Text("لديك حساب؟")
                }
                .padding(.top,550)
                
                
//                Text("لديك حساب؟ دخول")
//                    .padding(.top,550)
            }//z
        }
      
        
        
    }
}

#Preview {
    ContentView()
}
