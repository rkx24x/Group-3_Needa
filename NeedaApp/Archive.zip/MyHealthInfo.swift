//
//  MainPage.swift
//  NeedaApp
//
//  Created by shouq on 20/08/1445 AH.
//
import SwiftUI
import HealthKit

struct HealthDataEntryView: View {
    @State private var heartRate: Double = 0.0
    @State private var bodyTemperature: Double = 0.0
    @State private var bloodOxygen: Double = 0.0
    @State private var bloodPressureSystolic: Double = 0.0
    @State private var bloodPressureDiastolic: Double = 0.0
    
    private var healthStore: HKHealthStore?
    
    init() {
        if HKHealthStore.isHealthDataAvailable() {
            healthStore = HKHealthStore()
        }
    }
    
    var body: some View {
        NavigationView {
            
            ZStack {
                
                Image("background")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .edgesIgnoringSafeArea(.all)
                
                List {
                    HStack {
                        Text("نبضات القلب: \(heartRate, specifier: "%.0f") BPM")
                        .environment(\.layoutDirection, .rightToLeft)
                        Spacer()
                    }
                    HStack {
                        Text("درجة الحرارة: \(bodyTemperature, specifier: "%.1f") °C") .environment(\.layoutDirection, .rightToLeft)
                        Spacer()
                    }
                    HStack {
                        Text("أكسجين الدم: \(bloodOxygen, specifier: "%.1f") %")
                        Spacer()
                    }
                    HStack {
                        Text("Blood Pressure Systolic: \(bloodPressureSystolic, specifier: "%.0f") mmHg")
                        Spacer()
                    }
                    HStack {
                        Text("Blood Pressure Diastolic: \(bloodPressureDiastolic, specifier: "%.0f") mmHg")
                        Spacer()
                    }
                }  .listRowBackground(Color.clear) // Make list rows have a clear background
                    .background(Color.clear)
                .onAppear {
                    //  requestHealthKitAuthorization()
                }
                .navigationTitle("معلومات الصحية")
                .navigationBarTitleDisplayMode(.inline)
            }
        }}
    
    
    
    
    
    
    
    private func requestHealthKitAuthorization() {
        let healthKitTypesToRead: Set<HKObjectType> = [
            HKObjectType.quantityType(forIdentifier: .heartRate)!,
            HKObjectType.quantityType(forIdentifier: .bodyTemperature)!,
            HKObjectType.quantityType(forIdentifier: .oxygenSaturation)!,
            HKObjectType.quantityType(forIdentifier: .bloodPressureSystolic)!,
            HKObjectType.quantityType(forIdentifier: .bloodPressureDiastolic)!
        ]
        
        // Request authorization for those quantity types.
        healthStore?.requestAuthorization(toShare: nil, read: healthKitTypesToRead) { success, error in
            if success {
                // Authorization was successful
                fetchLatestHeartRate()
                fetchLatestBodyTemperature()
                fetchLatestBloodOxygen()
                fetchLatestBloodPressure()
            } else {
                // Handle the error here.
            }
        }
    }
    
    private func fetchLatestHeartRate() {
        // Code to fetch latest heart rate from HealthKit
        // Set the heartRate state variable with the fetched value
    }
    
    private func fetchLatestBodyTemperature() {
        // Code to fetch latest body temperature from HealthKit
        // Set the bodyTemperature state variable with the fetched value
    }
    
    private func fetchLatestBloodOxygen() {
        // Code to fetch latest blood oxygen from HealthKit
        // Set the bloodOxygen state variable with the fetched value
    }
    
    private func fetchLatestBloodPressure() {
        // Code to fetch latest blood pressure from HealthKit
        // Set the bloodPressureSystolic and bloodPressureDiastolic state variables with the fetched values
    }
}

struct HealthDataEntryView_Previews: PreviewProvider {
    static var previews: some View {
        HealthDataEntryView()
    }
}
