//
//  NeedaAppApp.swift
//  NeedaApp
//
//  Created by shouq on 17/08/1445 AH.
//

import SwiftUI

@main
struct NeedaAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
