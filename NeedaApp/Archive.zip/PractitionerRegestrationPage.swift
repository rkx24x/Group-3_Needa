//
//  PractitionerRegestrationPage.swift
//  NeedaApp
//
//  Created by shouq on 19/08/1445 AH.
//

import SwiftUI

struct PractitionerRegestrationPage: View {
    var body: some View {
        Text("صفحة الممارس الصحي ")
    }
}

#Preview {
    PractitionerRegestrationPage()
}
