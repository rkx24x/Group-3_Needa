//
//  completeYourHealthPage.swift
//  NeedaApp
//
//  Created by Reham  on 19/08/1445 AH.
//

import SwiftUI

struct completeYourHealthPage: View {
    @State private var firstPhoneNumber = ""
      @State private var secondPhoneNumber = ""
      @State private var height = ""
      @State private var weight = ""
      @State private var alargies = ""
      @State private var medicalNotes = ""
      @State private var previousSergiuers = ""
    private let elementPadding: CGFloat = 20

      var body: some View {
          ZStack {
              
              Image("background") // BackgraoundPrimeryColor
                  .resizable()
                  .aspectRatio(contentMode: .fill)
                  .edgesIgnoringSafeArea(.all)
      

              ScrollView {
                  VStack(spacing: 10) //20
                  {
                      Image("needasmall")
                          .offset(x:-100, y:40) //x:0, y: 60 -> x:-100, y:40
                      
                      Text("أكمل معلوماتك")
                          .font(.title)
                          .bold()
                          .padding(.all, -67.0) //30 ->
                          .offset(x:90, y:-20)
                          .foregroundColor(Color("button"))
                          .multilineTextAlignment(.trailing)
                      
                      Text("الصحية")
                          .font(.title)
                          .bold()
                          .padding([.top, .leading, .trailing], -40.0) //30 ->
                          .offset(x:100, y:-20)
                          .foregroundColor(Color("button"))
                          .multilineTextAlignment(.trailing)
                      
                      
                
                      
                      Group {
                          Text("رقم هاتف القريب الأول")
                              .foregroundColor(.black)
                              .frame(maxWidth: .infinity, alignment: .leading)
                          
                          // Phone number field with code
                          HStack {
                              Text("+966")
                                  .foregroundColor(.black)
                                  .padding(.leading, 10)
                              
                              Divider()
                                  .frame(height: 20)
                                  .background(Color.red)
                                  .padding(.horizontal, 5)
                              
                              TextField("", text: $firstPhoneNumber)
                                  .keyboardType(.numberPad)
                                  .foregroundColor(.black)
                          }
                          .frame(height: 20)
                          .overlay(
                              RoundedRectangle(cornerRadius: 10)
                                  .stroke(Color.white, lineWidth: 0)
                          )
                          .padding()
                          .background(Color.white)
                          .cornerRadius(10)
                      } .environment(\.layoutDirection, .rightToLeft)
                      
                
                      Group {
                          Text("رقم هاتف القريب الثاني")
                              .foregroundColor(.black)
                              .frame(maxWidth: .infinity, alignment: .leading)
                          
                          // Phone number field with code
                          HStack {
                              Text("+966")
                                  .foregroundColor(.black)
                                  .padding(.leading, 10)
                              
                              Divider()
                                  .frame(height: 20)
                                  .background(Color.red)
                                  .padding(.horizontal, 5)
                              
                              TextField("", text: $secondPhoneNumber)
                                  .keyboardType(.numberPad)
                                  .foregroundColor(.black)
                          }
                          .frame(height: 20)
                          .overlay(
                              RoundedRectangle(cornerRadius: 10)
                                  .stroke(Color.white, lineWidth: 0)
                          )
                          .padding()
                          .background(Color.white)
                          .cornerRadius(10)
                      } .environment(\.layoutDirection, .rightToLeft)
                  
    
                
                      
                      Group {
                          Text("الطول")
                              .foregroundColor(.black)
                              .frame(maxWidth: .infinity, alignment: .leading)
                          
                          TextField("", text: $height)
                              .textFieldStyle(RoundedBorderTextFieldStyle())
                          
                      }.environment(\.layoutDirection, .rightToLeft)
                      
                      Group {
                          Text("الوزن")
                              .foregroundColor(.black)
                              .frame(maxWidth: .infinity, alignment: .leading)
                          
                          TextField("", text: $weight)
                              .textFieldStyle(RoundedBorderTextFieldStyle())
                          
                      }.environment(\.layoutDirection, .rightToLeft)
                      
                      
                      Group {
                          Text("هل تعاني من حساسية؟")
                              .foregroundColor(.black)
                              .frame(maxWidth: .infinity, alignment: .leading)
                          
                          TextField("", text: $alargies)
                              .textFieldStyle(RoundedBorderTextFieldStyle())
                          
                      }.environment(\.layoutDirection, .rightToLeft)
                      
                      Group {
                          Text("العمليات السابقة")
                              .foregroundColor(.black)
                              .frame(maxWidth: .infinity, alignment: .leading)
                          
                          TextField("ماهي جميع العمليات السابقة التي قمت بها", text: $previousSergiuers)
                              .textFieldStyle(RoundedBorderTextFieldStyle())
                          
                      }.environment(\.layoutDirection, .rightToLeft)
                      
                      Group {
                          Text("الحالة و الملاحظات الطبية")
                              .foregroundColor(.black)
                              .frame(maxWidth: .infinity, alignment: .leading)
                          
                          TextField("", text: $medicalNotes)
                              .textFieldStyle(RoundedBorderTextFieldStyle())
                          
                      }.environment(\.layoutDirection, .rightToLeft)
                      
                     //if isLoading {
                       //   ProgressView()
                      //} else {
                          Button("التالي") {
                             // validateFields()
                          }
                          .frame(minWidth: 0, maxWidth: .infinity)
                          .padding()
                          .foregroundColor(.white)
                          .background( Color.button )
                        //  .background(isFormValid() ? Color.red : Color.gray)
                          .cornerRadius(10)
                         // .disabled(!isFormValid())
                          .padding(elementPadding)
                     // }
                      
                    
                  }
                  .padding(elementPadding)
              }//scroll
          }
      }
  }












#Preview {
    completeYourHealthPage()
}


