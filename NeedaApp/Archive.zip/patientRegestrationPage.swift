//
//  regestrationpage.swift
//  NeedaApp
//
//  Created by shouq on 19/08/1445 AH.
//

import SwiftUI
import Foundation
import CloudKit

enum Gender: String, CaseIterable, Identifiable {
    case male = "ذكر"
    case female = "أنثى"
    
    var id: String { self.rawValue }
}

struct patientRegestrationPage: View {
    
    @State private var showingcompleteYourHealthPage = false
    @Environment(\.presentationMode) var presentationMode
    @State private var firstName = ""
    @State private var lastName = ""
    @State private var age = ""
    @State private var gender: Gender = .male
    @State private var phoneNumber = ""
    @State private var email = ""
   // @State private var saveWord = ""
    @State private var password = ""
    @State private var confirmPassword = ""
    @State private var isLoading = false
    @State private var errorMessage = ""
    
    @State private var selectedAgeIndex = 0
    let ageOptions = ["18", "19", "20", "21", "22"]

    // Define consistent padding for all elements
    private let elementPadding: CGFloat = 20
    
    
    var body: some View {
        NavigationStack{
            ZStack {
                
                Image("background") // BackgraoundPrimeryColor
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .edgesIgnoringSafeArea(.all)
                
                
                VStack {
                                HStack {
                                    Button(action: {
                                        // Dismiss the current view to navigate back
                                        self.presentationMode.wrappedValue.dismiss()
                                    }) {
                                        HStack {
                                            Image(systemName: "chevron.backward") // The back arrow icon
                                            //Text("رجوع") // The text "Back"
                                        }
                                        .padding()
                                        .foregroundColor(.button) // Change the color as needed
                                    }
                                    Spacer() // Pushes the button to the left
                                }
                                // Make sure the rest of your content is pushed down
                                Spacer()
                            }
                            .padding(.leading)
                            .zIndex(1)
                
                ScrollView {
                    VStack(spacing: 10) //20
                    {
                        Image("needasmall")
                            .offset(x:-100, y:40) //x:0, y: 60 -> x:-100, y:40
                        
                        Text("إنشاء حساب ")
                            .font(.title)
                            .bold()
                            .padding(.all, -60.0) //30 ->
                            .offset(x:100, y:-20)
                            .foregroundColor(Color("button"))
                            .multilineTextAlignment(.trailing)
                        
                        Text("مستخدم ")
                            .font(.title)
                            .bold()
                            .padding([.top, .leading, .trailing], -40.0) //30 ->
                            .offset(x:100, y:-20)
                            .foregroundColor(Color("button"))
                            .multilineTextAlignment(.trailing)
                        
                        
                        //                    Group {
                        //                        Text("الاسم الأول")
                        //                            .foregroundColor(.black)
                        //                            .frame(maxWidth: 80, alignment: .leading)
                        ////                            .frame(maxWidth: .infinity, alignment: .leading)
                        //                        TextField("مثلًا: سارة التميمي", text: $firstName)
                        //                            .textFieldStyle(RoundedBorderTextFieldStyle())
                        //                            .environment(\.layoutDirection, .rightToLeft)
                        //
                        //                        Text("اسم العائلة")
                        //                            .foregroundColor(.black)
                        //                            .frame(maxWidth: .infinity, alignment: .leading)
                        //
                        //                        TextField("مثلًا: سارة التميمي", text: $lastName)
                        //                            .textFieldStyle(RoundedBorderTextFieldStyle())
                        //                            .environment(\.layoutDirection, .rightToLeft)
                        //
                        //                    } .environment(\.layoutDirection, .rightToLeft)
                        
                        Group{
                            VStack {
                                HStack {
                                    VStack {
                                        
                                        Text("الاسم الأول")
                                            .foregroundColor(.black)
                                            .frame(maxWidth: .infinity, alignment: .leading)
                                        
                                        TextField("مثلًا: سارة ", text: $firstName)
                                            .textFieldStyle(RoundedBorderTextFieldStyle())
                                            .environment(\.layoutDirection, .rightToLeft)
                                    }//end of VStack
                                    
                                    Spacer()
                                    
                                    VStack {
                                        Text("اسم العائلة")
                                            .foregroundColor(.black)
                                            .multilineTextAlignment(.trailing)
                                            .frame(maxWidth: .infinity, alignment: .leading)
                                        
                                        TextField("مثلًا: التميمي", text: $lastName)
                                            .textFieldStyle(RoundedBorderTextFieldStyle())
                                            .environment(\.layoutDirection, .rightToLeft)
                                    } //end of VStack
                                } // end of HStack
                            } //end of VStack
                        }.environment(\.layoutDirection, .rightToLeft) //end of group1
                        
                        
                        Group {
                            Text("العمر")
                                .foregroundColor(.black)
                                .frame(maxWidth: .infinity, alignment: .leading)
                            
                            
                            TextField("", text: $age)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                                .environment(\.layoutDirection, .rightToLeft)
                            
                            
                            
                            
                        } .environment(\.layoutDirection, .rightToLeft) //end of group2
                        
                        
                        Group {
                            Text("الجنس")
                                .foregroundColor(.black)
                                .frame(maxWidth: .infinity, alignment: .leading)
                            
                            Menu {
                                Picker("", selection: $gender) {
                                    ForEach(Gender.allCases) { gender in
                                        Text(gender.rawValue).tag(gender)
                                    }
                                }
                            } label: {
                                HStack {
                                    Text(gender.rawValue)
                                        .foregroundColor(.black)
                                    Spacer()
                                    Image(systemName: "chevron.down")
                                        .foregroundColor(.gray)
                                }
                                .padding()
                                .frame(minWidth: 0, maxWidth: .infinity)
                                .background(Color.white)
                                .cornerRadius(10)
                            }
                            .accentColor(.white)
                            .environment(\.layoutDirection, .rightToLeft)
                        } .environment(\.layoutDirection, .rightToLeft) //end of group3
                        
                        Group {
                            Text("رقم الهاتف")
                                .foregroundColor(.black)
                                .frame(maxWidth: .infinity, alignment: .leading)
                            
                            // Phone number field with code
                            HStack {
                                Text("+966")
                                    .foregroundColor(.black)
                                    .padding(.leading, 10)
                                
                                Divider()
                                    .frame(height: 20)
                                    .background(Color.red)
                                    .padding(.horizontal, 5)
                                
                                TextField("", text: $phoneNumber)
                                    .keyboardType(.numberPad)
                                    .foregroundColor(.black)
                            }
                            .frame(height: 20)
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(Color.white, lineWidth: 0)
                            )
                            .padding()
                            .background(Color.white)
                            .cornerRadius(10)
                        } .environment(\.layoutDirection, .rightToLeft)
                        
                        Group {
                            Text("البريد الإلكتروني")
                                .foregroundColor(.black)
                                .frame(maxWidth: .infinity, alignment: .leading)
                            
                            TextField("", text: $email)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                            
                        }.environment(\.layoutDirection, .rightToLeft) //end of group4
                        
                        /*        Group {
                         Text("كلمة الامان")
                         .foregroundColor(.gray)
                         .frame(maxWidth: .infinity, alignment: .leading)
                         .environment(\.layoutDirection, .rightToLeft)
                         
                         TextField("", text: $saveWord)
                         .textFieldStyle(RoundedBorderTextFieldStyle())
                         .environment(\.layoutDirection, .rightToLeft)
                         }.environment(\.layoutDirection, .rightToLeft) */
                        
                        Group {
                            Text("الرمز السري")
                                .foregroundColor(.black)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .environment(\.layoutDirection, .rightToLeft)
                            
                            SecureField("", text: $password)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                            
                        }
                        
                        Group {
                            Text("تأكيد الرمز السري")
                                .foregroundColor(.black)
                                .frame(maxWidth: .infinity, alignment: .leading)
                            
                            
                            SecureField("", text: $confirmPassword)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                            
                        }.environment(\.layoutDirection, .rightToLeft) //end of group5
                        
                       
                        
                        
                        
                        
                        NavigationLink(destination: completeYourHealthPage()            .navigationBarBackButtonHidden(true),label:{
                            HStack{
                                
                                Text("التالي")
                                    .frame(width:300, height:50)
                                    .foregroundColor(Color.white)
                                    .background(Color.button)
                                    .cornerRadius(8)
                                    .padding()
                                
                            } .padding(.bottom,200)
                        }
                        )
                        
                        
                        
                        
                        
                        
                       /*     Button("التالي") {
                                self.showingcompleteYourHealthPage = true
                                //validateFields()
                            }
                            .frame(minWidth: 0, maxWidth: .infinity)
                            .padding()
                            .foregroundColor(.white)
                            .background(isFormValid() ? Color.red : Color.gray)
                            .cornerRadius(10)
                            //.disabled(!isFormValid())
                            .padding(elementPadding)
                            .padding()
                                .fullScreenCover(isPresented: $showingcompleteYourHealthPage) {
                                    completeYourHealthPage()
                        }*/
                                
                          
                        
                        
                        
                        
                        
                        /*  if isLoading {
                         ProgressView()
                     } else {
                         Button("التالي") {
                             self.showingcompleteYourHealthPage = true
                             //validateFields()
                         }
                         .frame(minWidth: 0, maxWidth: .infinity)
                         .padding()
                         .foregroundColor(.white)
                         .background(isFormValid() ? Color.red : Color.gray)
                         .cornerRadius(10)
                         .disabled(!isFormValid())
                         .padding(elementPadding)
                         .padding()
                             .fullScreenCover(isPresented: $showingcompleteYourHealthPage) {
                                 completeYourHealthPage()
                     }
                             
                         } */
                        
                        if !errorMessage.isEmpty {
                            Text(errorMessage)
                                .foregroundColor(.red)
                                .padding(elementPadding)
                        }
                    }
                    .padding(elementPadding)
                }
            }.navigationBarHidden(true)
        }
        
        
        
    }
    
    
    
    
    
    
    
    
    
    
   
    
    func getFullPhoneNumber() -> String {
        if phoneNumber.starts(with: "+966") {
            return phoneNumber
        } else {
            return "+966" + phoneNumber
        }
    }
    
    func validateFields() {
        isLoading = true
        errorMessage = ""
        
        if firstName.isEmpty {
            errorMessage = "Please enter your first name."
            isLoading = false
            return
        }
        
        if age.isEmpty {
            errorMessage = "Please enter your age."
            isLoading = false
            return
        }
        
        if phoneNumber.isEmpty {
            errorMessage = "Please enter your phone number."
            isLoading = false
            return
        }
        
        if email.isEmpty {
            errorMessage = "Please enter your email."
            isLoading = false
            return
        }
     /*
        if saveWord.isEmpty {
            errorMessage = "Please enter your save word."
            isLoading = false
            return
        }*/
        
        if password.isEmpty {
            errorMessage = "Please enter your password."
            isLoading = false
            return
        }
        
        if confirmPassword.isEmpty {
            errorMessage = "Please confirm your password."
            isLoading = false
            return
        }
        
        if !isPasswordStrong(password) {
            errorMessage = "The password does not meet the complexity requirements."
            isLoading = false
            return
        }
        
        if password != confirmPassword {
            errorMessage = "The passwords do not match."
            isLoading = false
            return
        }
        
      //  let user = createUser()
      //  saveUserToCloudKit(user)
    }
    
    func isFormValid() -> Bool {
        !firstName.isEmpty &&
        !age.isEmpty &&
        !phoneNumber.isEmpty &&
        !email.isEmpty &&
       // !saveWord.isEmpty &&
        isPasswordStrong(password) &&
        password == confirmPassword
    }
    
    
    
    func isPasswordStrong(_ password: String) -> Bool {
        let passwordTest = NSPredicate(format: "SELF MATCHES %@", "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$")
        return passwordTest.evaluate(with: password)}



    func createUser() -> User {
           return User(firstName: firstName, age: Int(age) ?? 0, gender: gender, phoneNumber: phoneNumber, email: email, password: password, confirmPassword: confirmPassword)
       }                                    }




struct User {
    var firstName: String
    var age: Int
    var gender: Gender
    var phoneNumber: String
    var email: String
    //var saveWord: String
    var password: String
    var confirmPassword: String
}

func saveUserToCloudKit(_ user: User) {
    let container = CKContainer(identifier: "iCloud.com.yourcompany.yourapp")
    let publicDB = container.publicCloudDatabase
    
    let userRecord = CKRecord(recordType: "User")
    
    /*
     userRecord["firstName"] = user.firstName as CKRecordValue
     userRecord["age"] = user.age as CKRecordValue
     userRecord["gender"] = user.gender.rawValue as CKRecordValue
     userRecord["phoneNumber"] = user.phoneNumber as CKRecordValue
     userRecord["saveWord"] = user.saveWord as CKRecordValue
     userRecord["email"] = user.email as CKRecordValue
     userRecord["password"] = user.password as CKRecordValue
     
     publicDB.save(userRecord) { (record, error) in
     if let error = error {
     print("Error saving user to CloudKit: \(error)")
     } else {
     print("User saved to CloudKit: \(record!.recordID)")
     }
     }
     
     
     */
}

#Preview {
    patientRegestrationPage()
}
